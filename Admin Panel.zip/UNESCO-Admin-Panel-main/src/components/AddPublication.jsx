import React from 'react';

function AddPublication(props) {
  return (
    <form className="form">
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            name="name"
            placeholder="Publication Name"
            value={props.name}
            onChange={(e) => {
              props.setName(e.target.value);
            }}
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            name="link"
            placeholder="Publication Link"
            value={props.link}
            onChange={(e) => {
              props.setLink(e.target.value);
            }}
          />
        </div>

        <button
          type="button"
          className=" btn btn-primary save-button"
          onClick={props.handleSubmit}
        >
          Add
        </button>
      </form>
  );
}

export default AddPublication;
