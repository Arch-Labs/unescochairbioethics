import React from "react";
import { useState, useEffect } from "react";
import "../style/Page.scss";
import axios from "axios";
import LoadingScreen from "react-loading-screen";
import AddPublication from "./AddPublication";
import UpdatePublication from "./UpdatePublication";
const token = sessionStorage.getItem('token')

function Publication() {
  const [publication, setPublication] = useState([]);
  const [loading, setLoading] = useState(true);
  const [update, setUpdate] = useState(false);

  const getPublication = async () => {
    setLoading(true);
    await axios.get("https://unesco-bioethicon.herokuapp.com/publication").then((res) => {
      const data = res.data;
      data.reverse();
      setPublication(data);
    });
    setLoading(false);
  };

  useEffect(() => {
    getPublication();
    setUpdate(false);
  }, [update]);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure?")) {
      await axios.delete("https://unesco-bioethicon.herokuapp.com/publication/" + id,
      {
        headers: {
          Authorization: 'Bearer ' + token
        }
      }
      );
      alert("Deleted Sucessfully!");
      setUpdate(true);
      window.history.go()
    }
  };

  const [name, setName] = useState("");
  const [link, setLink] = useState("");

  const handleSubmit = async () => {
    const publication = {
      name: name,
      link: link,
    };

    if (name && link) {
      await axios
        .post("https://unesco-bioethicon.herokuapp.com/publication", publication,
        {
          headers: {
            Authorization: 'Bearer ' + token
          }
        })
        .then((res) => {
          console.log(res);
          setName("");
          setLink("");
        });
    } else {
      alert("Fill all The Informations");
    }
    setUpdate(true);
    window.history.go()
  };

  return (
    <div className="Page">
      <LoadingScreen
        loading={loading}
        bgColor="#ffffff"
        spinnerColor="#01471B"
        textColor="#01471B"
        logoSrc="https://res.cloudinary.com/unesco-admin/image/upload/v1645289463/image003-removebg-preview_dkzzc8.png"
        text="Fetching Publication's"
      ></LoadingScreen>

      <h1 id="heading">Publication's</h1>
      <h3 className="subHeadings">Current Publication's: </h3>

      {publication.length > 0
        ? publication.map((value, index) => {
            return (
              <div className="card contactCard">
                <ul className="list-group list-group-flush">
                  <li className="list-group-item">
                    <b>Publication Heading: </b> {value.name}
                  </li>
                  <li className="list-group-item">
                    <b>Publication Link: </b> {value.link}
                  </li>
                </ul>

                <UpdatePublication id={index} data={value} mongoid={publication[index]._id} setUpdate={setUpdate}/>

                <div className="d-flex">
                  <button
                    className="btn btn-primary w-50"
                    data-bs-toggle="modal"
                    data-bs-target={`#Modal${index}`}
                    id={index}
                  >
                    Update
                  </button>

                  <button
                    className="btn btn-danger delete w-50"
                    id={index}
                    onClick={(e) => {
                      handleDelete(publication[e.target.id]._id);
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            );
          })
        : null}

      <h3 className="subHeadings">Add Publication: </h3>
      <AddPublication
        name={name}
        link={link}
        setName={setName}
        setLink={setLink}
        handleSubmit={handleSubmit}
      />
    </div>
  );
}

export default Publication;
