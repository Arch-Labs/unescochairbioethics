import React, {useState} from "react";
import axios from "axios";

function UpdatePublication(props) {
  const [name, setName] = useState(props.data.name);
  const [link, setLink] = useState(props.data.link);

  const token = sessionStorage.getItem('token')

  const updPublication = (id)=>{
    axios
      .patch("https://unesco-bioethicon.herokuapp.com/publication/" + id , {
        name: name,
        link: link,
      },
      {
        headers: {
          Authorization: 'Bearer ' + token
        }
      }
      )
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
      
      alert("Updated!")
      props.setUpdate(true)
  }

  return (
    <div className="modal fade" id={`Modal${props.id}`} tabindex="-1">
      <div className="modal-dialog">
        <div className="modal-content">

        <h2 className="mx-auto mt-3">Update Publication</h2>
          <form className="form">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                name="name"
                placeholder="Mou nameing"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                name="link"
                placeholder="Publication link"
                value={link}
                onChange={(e) => {
                  setLink(e.target.value);
                }}
              />
            </div>
          </form>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Close
            </button>
            <button className="btn btn-primary" data-bs-dismiss="modal" onClick={()=>{updPublication(props.mongoid)}}>
              Save changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UpdatePublication;
