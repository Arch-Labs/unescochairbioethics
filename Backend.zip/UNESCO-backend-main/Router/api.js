const express = require("express")
const router = new express.Router()
const jwt = require("jsonwebtoken")
const { notice, upcomingEvents, contact, news, corousel, mou, publication, webinar, gallery, studentunit } = require('../models/Schema')
const upload = require("./multer");
const cloudinary = require("./cloudinary");
const auth = require("../auth/auth");
const utils = require("./utils")

// MIDDLEWARE FOR JWT

router.use(function (req, res, next) {
    // var token = req.headers['authorization'];
    const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]
    if (!token) return next();
    // token = token.replace('Bearer ', '');
    jwt.verify(token, "UNESCOsecretkey", function (err, user) {
        if (err) {
            return res.status(401).json({
                error: true,
                message: "Invalid user."
            });
        } else {
            req.user = user;
            next();
        }
    });
});

router.get("/", (req, res) => {
    res.send("Hey This is Working")
})


// Student Units
router.post("/studentUnit", auth, async (req, res) => {
    const { sno, unit, university, unitHead, report, reportid } = req.body;
    const units = new studentunit({
        sno,
        unit,
        university,
        unitHead,
        report,
        reportid
    })

    units.save((err) => {
        if (err) {
            res.status(400).send(err)
        } else {
            res.status(201).send("Succesfully Registered ")
        }
    })
})

router.get("/studentUnit", (req, res) => {
    studentunit.find().then((result) => {
        res.status(200).send(result)
    }).catch((err) => {
        res.status(404).send(err)
    })
})

router.delete("/studentUnit/:id", auth, async (req, res) => {
    try {
        // Find user by id
        let user = await studentunit.findById(req.params.id);
        // Delete image from cloudinary
        await cloudinary.uploader.destroy(user.reportid);
        // Delete user from db
        const id = req.params.id
        const result = await studentunit.findByIdAndDelete(id)
        res.json(result);
    } catch (err) {
        console.log(err);
    }
});



//Gallery

router.post("/gallery", auth, upload.single("image"), async (req, res) => {
    try {
        // Upload image to cloudinary
        const result = await cloudinary.uploader.upload(req.file.path);
        // res.send(result.secure_url);
        const url = result.secure_url;
        const cloudinaryId = result.public_id;
        // Create new user
        let user = new gallery({
            description: req.body.description,
            avatar: url,
            cloudinary_id: cloudinaryId,
        });
        // Save user
        await user.save();
        res.json(user);
    } catch (err) {
        console.log(err);
    }
});


router.get("/gallery", async (req, res) => {
    try {
        let user = await gallery.find();
        res.json(user);
    } catch (err) {
        console.log(err);
    }
});


router.delete("/gallery/:id", auth, async (req, res) => {
    try {
        // Find user by id
        let user = await gallery.findById(req.params.id);
        // Delete image from cloudinary
        await cloudinary.uploader.destroy(user.cloudinary_id);
        // Delete user from db
        const id = req.params.id
        await gallery.findByIdAndDelete(id)
        res.json(user);
    } catch (err) {
        console.log(err);
    }
});



//Webinar
router.post("/webinar", auth, async (req, res) => {
    const { series, topic, videourl, videoid, summaryurl, summaryid } = req.body;
    const webinars = new webinar({
        series,
        topic,
        videourl,
        videoid,
        summaryurl,
        summaryid
    })

    webinars.save((err) => {
        if (err) {
            res.status(400).send(err)
        } else {
            res.status(201).send("Succesfully Registered ")
        }
    })
})

router.get("/webinar", (req, res) => {
    webinar.find().then((result) => {
        res.status(200).send(result)
    }).catch((err) => {
        res.status(404).send(err)
    })
})

router.delete("/webinar/:id", auth, async (req, res) => {
    try {
        // Find user by id
        let user = await webinar.findById(req.params.id);
        // Delete image from cloudinary
        await cloudinary.uploader.destroy(user.videoid);
        await cloudinary.uploader.destroy(user.summaryid);

        // Delete user from db
        const id = req.params.id
        const result = await webinar.findByIdAndDelete(id)
        res.json(result);
    } catch (err) {
        console.log(err);
    }
});

//Carousel

router.post("/corousel", auth, upload.single("image"), async (req, res) => {
    try {
        // Upload image to cloudinary
        const result = await cloudinary.uploader.upload(req.file.path);
        const url = result.secure_url;
        const cloudinaryId = result.public_id;
        // Create new user
        let user = new corousel({
            name: req.body.name,
            avatar: url,
            cloudinary_id: cloudinaryId,
        });
        // Save user
        await user.save();
        res.json(user);
    } catch (err) {
        console.log(err);
    }
});

router.get("/corousel", async (req, res) => {
    try {
        let user = await corousel.find();
        res.json(user);
    } catch (err) {
        console.log(err);
    }
});

router.delete("/corousel/:id", auth, async (req, res) => {
    try {
        // Find user by id
        let user = await corousel.findById(req.params.id);
        // Delete image from cloudinary
        await cloudinary.uploader.destroy(user.cloudinary_id);
        // Delete user from db
        const id = req.params.id
        await corousel.findByIdAndDelete(id)
        res.json(user);
    } catch (err) {
        console.log(err);
    }
});


//Contact

router.post("/contact", (req, res) => {
    const { name, email, phone, message, role, interest } = req.body
    const contacts = new contact({
        name,
        email,
        phone,
        message,
        role,
        interest
    })
    contacts.save((err) => {
        if (err) {
            res.status(400).send(err)
        } else {
            res.status(201).send("Succesfully Registered")
        }
    })
})

router.get("/contact", (req, res) => {
    contact.find().then((result) => {
        res.status(200).send(result)
    }).catch((err) => {
        res.status(404).send(err)
    })
})

router.delete("/contact/:id", auth, async (req, res) => {
    try {
        const id = req.params.id;
        const deletedCon = await contact.findByIdAndDelete(id);
        if (!id) {
            res.status(400).send()

        } else {
            res.send(`Deleted Successfully ${deletedCon}`);
        }
    } catch (e) {
        res.status(500).send(e);
    }
})


// NOTICES 

router.post("/notice", auth, (req, res) => {
    const { day, month, noticeHead, noticeDes, link } = req.body
    const notices = new notice({
        day,
        month,
        noticeHead,
        noticeDes,
        link
    })
    notices.save((err) => {
        if (err) {
            res.status(400).send(err)
        } else {
            res.status(201).send("Succesfully Registered")
        }
    })
})


router.get("/notice", (req, res) => {
    notice.find().then((result) => {
        res.status(200).send(result)
    }).catch((err) => {
        res.status(404).send(err)
    })
})


router.delete("/notice/:id", auth, async (req, res) => {
    try {
        const id = req.params.id;
        const deletedCon = await notice.findByIdAndDelete(id);
        if (!id) {
            res.status(400).send()

        } else {
            res.send(`Deleted Successfully ${deletedCon}`);
        }
    } catch (e) {
        res.status(500).send(e);
    }
})


router.patch("/notice/:id", auth, async (req, res) => {
    try {
        const _id = req.params.id;
        const updatedNews = await notice.findByIdAndUpdate(_id, req.body);
        res.send(`News updated Successfully ${updatedNews}`)
    } catch (e) {
        res.send(e)
    }
})


// UPCOMING EVENTS

router.post("/upcomingevent", auth, (req, res) => {
    const { day, month, upeventsHead, upeventsDes, link } = req.body
    const upcomingevent = new upcomingEvents({
        day,
        month,
        upeventsHead,
        upeventsDes,
        link
    })
    upcomingevent.save((err) => {
        if (err) {
            res.send(err)
        } else {
            res.status(201).send("Succesfully Registered")
        }
    })
})

router.get("/upcomingevent", (req, res) => {
    upcomingEvents.find().then((result) => {
        res.send(result)
    }).catch((err) => {
        res.send(err)
    })
})


router.patch("/upcomingevent/:id", auth, async (req, res) => {
    try {
        const _id = req.params.id;
        const updatedNews = await upcomingEvents.findByIdAndUpdate(_id, req.body);
        res.send(`News updated Successfully ${updatedNews}`)
    } catch (e) {
        res.send(e)
    }
})

router.delete("/upcomingevent/:id", auth, async (req, res) => {
    try {
        const id = req.params.id;
        const deletedCon = await upcomingEvents.findByIdAndDelete(id);
        if (!id) {
            res.status(400).send()
        } else {
            res.send(`Deleted Successfully ${deletedCon}`);
        }
    } catch (e) {
        res.status(500).send(e);
    }
})

// NEWS HEADING

router.post("/news", auth, (req, res) => {
    const { newshead } = req.body
    const newss = new news({
        newshead
    })
    newss.save((err) => {
        if (err) {
            res.send(err)
        } else {
            res.send("Succesfully Registered")
        }
    })
})

router.get("/news", (req, res) => {
    news.find().then((result) => {
        res.send(result)
    }).catch((err) => {
        res.send(err)
    })
})

router.patch("/news", auth, async (req, res) => {
    try {
        const _id = "61fd5dae1d9655fe2b9ef032";
        const updatedNews = await news.findByIdAndUpdate(_id, req.body);
        res.send(`News updated Successfully ${updatedNews}`)

    } catch (e) {
        res.send(e)
    }
})

//Mou's

router.post("/mou", auth, (req, res) => {
    const { head, description } = req.body
    const mous = new mou({
        head,
        description
    })
    mous.save((err) => {
        if (err) {
            res.status(400).send(err)
        } else {
            res.status(201).send("Succesfully Registered")
        }
    })
})

router.get("/mou", (req, res) => {
    mou.find().then((result) => {
        res.send(result)
    }).catch((err) => {
        res.send(err)
    })
})


router.patch("/mou/:id", auth, async (req, res) => {
    try {
        const _id = req.params.id;
        const updatedNews = await mou.findByIdAndUpdate(_id, req.body);
        res.send(`News updated Successfully ${updatedNews}`)
    } catch (e) {
        res.send(e)
    }
})

router.delete("/mou/:id", auth, async (req, res) => {
    try {
        const id = req.params.id;
        const deletedCon = await mou.findByIdAndDelete(id);
        if (!id) {
            res.status(400).send()

        } else {
            res.send(`Deleted Successfully ${deletedCon}`);
        }
    } catch (e) {
        res.status(500).send(e);
    }
})

//Publication API
router.post("/publication", auth, (req, res) => {
    const { name, link, imgLink } = req.body
    const publications = new publication({
        name,
        link,
        imgLink
    })
    publications.save((err) => {
        if (err) {
            res.status(400).send(err)
        } else {
            res.status(201).send("Succesfully Registered")
        }
    })
})

router.get("/publication", (req, res) => {
    publication.find().then((result) => {
        res.send(result)
    }).catch((err) => {
        res.send(err)
    })
})


router.patch("/publication/:id", auth, async (req, res) => {
    try {
        const _id = req.params.id;
        const updatedNews = await publication.findByIdAndUpdate(_id, req.body);
        res.send(`News updated Successfully ${updatedNews}`)
    } catch (e) {
        res.send(e)
    }
})

router.delete("/publication/:id", auth, async (req, res) => {
    try {
        const id = req.params.id;
        const deletedCon = await publication.findByIdAndDelete(id);
        if (!id) {
            res.status(400).send()

        } else {
            res.send(`Deleted Successfully ${deletedCon}`);
        }
    } catch (e) {
        res.status(500).send(e);
    }
})

// LOGIN CREDENTIALS FOR ADMIN PANEL

const userData = {
    userId: process.env.U_ID,
    password: "123",
    name: process.env.NAME,
    username: "unesco",
    isAdmin: true
};


//Admin panel

router.post('/login', function (req, res) {
    const user = req.body.username;
    const pwd = req.body.password;

    if (!user || !pwd) {
        return res.status(400).json({
            error: true,
            message: "Username or Password required."
        });
    }

    if (user !== userData.username || pwd !== userData.password) {
        return res.status(401).json({
            error: true,
            message: "Username or Password is Wrong."
        });
    }
    const token = utils.generateToken(userData);
    const userObj = utils.getCleanUser(userData);
    return res.json({ user: userObj, token });
});

// ADMIN PANEL LOGIN VERIFICATION

router.get('/verifyToken', function (req, res) {
    var token = req.body.token || req.query.token;
    if (!token) {
        return res.status(400).json({
            error: true,
            message: "Token is required."
        });
    }
    jwt.verify(token, "UNESCOsecretkey", function (err, user) {
        if (err) return res.status(401).json({
            error: true,
            message: "Invalid token."
        });

        if (user.userId !== userData.userId) {
            return res.status(401).json({
                error: true,
                message: "Invalid user."
            });
        }
        var userObj = utils.getCleanUser(userData);
        return res.json({ user: userObj, token });
    });
});


module.exports = router;