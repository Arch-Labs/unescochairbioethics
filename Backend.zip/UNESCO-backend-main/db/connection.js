const mongoose = require("mongoose")

const uri = process.env.DB_URL || 'mongodb://localhost:27017/UNESCO';
mongoose.connect(uri, {
    useNewUrlParser: true,
    useunifiedTopology: true
}, () => {
    console.log("DB Connected")
    
})