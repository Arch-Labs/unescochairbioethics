const mongoose = require("mongoose")

const ContactSchema = new mongoose.Schema({
    name: String,
    email: String,
    phone: Number,
    message: String,
    role: String,
    interest: String
})


const NoticeSchema = new mongoose.Schema({
    day: Number,
    month: String,
    noticeHead: String,
    noticeDes: String,
    link: String
})

const UpcomingEventsSchema = new mongoose.Schema({
    day: Number,
    month: String,
    upeventsHead: String,
    upeventsDes: String,
    link: String
})


const CorouselSchema = new mongoose.Schema({
    name: String,
    avatar: String,
    cloudinary_id: String
})

const NewsSchema = new mongoose.Schema({
    newshead: String
})

const MouSchema = new mongoose.Schema({
    head: String,
    description: String
})

const PublicationSchema = new mongoose.Schema({
    name: String,
    link: String,
    imgLink:String
})

const WebinarSchema = new mongoose.Schema({
    series: String,
    topic: String,
    videourl: String,
    videoid: String,
    summaryurl: String,
    summaryid: String
})

const GallerySchema = new mongoose.Schema({
    description: String,
    avatar: String,
    cloudinary_id: String,
})

const StudentUnitSchema = new mongoose.Schema({
    sno :Number,
    unit:String,
    university:String,
    unitHead:String,
    report:String,
    reportid:String
})

const upcomingEvents = new mongoose.model("upcomingEvents", UpcomingEventsSchema)
const notice = new mongoose.model("notice", NoticeSchema)
const contact = new mongoose.model("contact", ContactSchema)
const corousel = new mongoose.model("corousel", CorouselSchema)
const news = new mongoose.model("news", NewsSchema)
const mou = new mongoose.model("mou", MouSchema)
const publication = new mongoose.model("publication", PublicationSchema)
const webinar = new mongoose.model("webinar", WebinarSchema)
const gallery = new mongoose.model("gallery", GallerySchema)
const studentunit =new mongoose.model("studentunit",StudentUnitSchema)

module.exports = { upcomingEvents, notice, contact, corousel, news, mou, publication, webinar, gallery, studentunit }