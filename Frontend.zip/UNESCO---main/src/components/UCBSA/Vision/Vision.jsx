import React from "react";
import "./Vision.scss";

const VisionCompponent = ({ heading, points, flexState, imgLink, imgWidth }) => {
  return (
    <div
      className={`vision__container ${!flexState?'vision__container__reverse':''}` }
    >
      <div className="vision-img-container" >
        <img
          src={imgLink}
        
          className={`vision-img-container__img ${flexState?'vision-img-container__img__largeImg':''}`}
          alt=""
        />
      </div>
      <div className="vision__container__text"   >
          
        <h4 className="vision__container__text__heading">{heading}</h4>
        <div className="vision__container__text__content">
          <ul>
            {points.map((point) => (
              <li>{point}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

const Vision = () => {
  return (
    <>
      <VisionCompponent
        heading="Vision"
        points={[
          "ICBSA is committed to nurturing youth in the realms of Bioethics and Human rights with the aim of ensuring youth advocacy and participation by disseminating, improving and monitoring ethics education and research in health care delivery.",
          "Reflecting, from a student’s perspective about the need for ethics integration in the practice of medicine as well as increasing interest in values involved in healthcare delivery and increasing awareness for competing interests.",
          "Introducing medical students to other facets of medicine like ethical practice, sociology, economics and public administration.",
          "Reporting feedback from students in developing novel, modern and sophisticated educational tools and materials that facilitate teaching.",
        ]}
        flexState
        imgLink='https://res.cloudinary.com/unesco-admin/image/upload/v1649182552/Group_3546_ctumws.jpg'
        imgWidth='100%'

      />
      <VisionCompponent
        heading="Objectives"
        points={[
          "Promoting youth bioethics education via the international certificate course and capacity building toolkits as well as workshops",
          "Increasing student participation at World Bioethics Conferences",
          "Increasing student participation at the scholarly publication of the International Chair in Bioethics; ‘Global Bioethics Enquiry’",
          "Provide outreach and readership amongst students for the newsletter of the International Chair in Bioethics; ‘Bioethical voices’.","Increase engagement of students in educational and research programmes in Bioethics and allied sciences of healthcare.","Increasing International cooperation and friendship.","Enhancing student interaction by facilitating electives and exchanges.","Promoting publications and literature in Bioethics and allied sciences.",
        ]}
        imgLink="https://res.cloudinary.com/unesco-admin/image/upload/v1649174895/%D0%9C%D0%BE%D0%BD%D1%82%D0%B0%D0%B6%D0%BD%D0%B0%D1%8F_%D0%BE%D0%B1%D0%BB%D0%B0%D1%81%D1%82%D1%8C_2_2_jip8yn.png"
        imgWidth='100%'

        
      />
    </>
  );
};

export default Vision;
