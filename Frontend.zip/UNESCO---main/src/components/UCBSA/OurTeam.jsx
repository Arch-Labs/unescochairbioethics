import React from "react";

function OurTeam() {
  return (
    <div className="ourTeam">
      <div className="heading">
        <h3>OUR</h3>
        <h3 className="green">TEAM</h3>
      </div>

      <div className="row">
          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1644006363/Rounak_ukpp5x.png" alt="" />
              <p className="teamname">Rounak Verma (India)</p>
              <p></p>
              <p>President</p>
          </div>

          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1644006362/Frances_ynz5rq.png" alt="" />
              <p className="teamname">Frances Chukwu (Nigeria)</p>
              <p>Vice President Internal Affairs</p>
          </div>
          
          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1649244323/Darja_f1cr1x_me8xcb.jpg" alt="" />
              <p className="teamname">Darja Popkova (Latvia)</p>
              <p>Vice President External Affairs</p>
          </div>

          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1649244303/Jason_cejyx1_cvch2g.png" alt="" />
              <p className="teamname">Jason Fang (USA)</p>
              <p>Vice President Engagement</p>
          </div>

          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1644006364/Alara_lgkuus.png" alt="" />
              <p className="teamname">Alara Radavus (Turkey)</p>
              <p>Vice President Education</p>
          </div>
          
          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1644006364/Anna_uxoyu9.png" alt="" />
              <p className="teamname">Anna Tapani (Greece)</p>
              <p>Vice President Capacity Building</p>
          </div>

          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1649244303/Lina_tjqyod_c7dgeq.png" alt="" />
              <p className="teamname">Lina Ardilla (Colombia)</p>
              <p>Vice President P.R. and Communication</p>
          </div>

          <div className="col-md-3">
              <img src="https://res.cloudinary.com/unesco-admin/image/upload/v1644006362/IMG_20210422_112141_528_1_iwkkqk.jpg" alt="" />
              <p className="teamname"> Pratyush Kumar (India)</p>
              <p>Secretary</p>
          </div>
      </div>
    </div>
  );
}

export default OurTeam;
