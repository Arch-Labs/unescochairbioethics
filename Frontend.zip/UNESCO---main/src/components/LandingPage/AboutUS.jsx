import React from "react";
import "../.././Style/LandingPage/Aboutus.scss";
import ModalImage from "react-modal-image";

function AboutUS() {
  return (
    <div className="AboutUs">
      <h1>About Us:</h1>

      <div className="images">
        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643981842/Amnon_Carmi_snin9g.png"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643981842/Amnon_Carmi_snin9g.png"
            alt="image2"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">PROF. AMNON CARMI</p>
          <p className="designation">
            CHAIR<span className="and"> & </span>HEAD OF INTERNATIONAL CHAIR IN
            BIOETHICS
          </p>
        </div>

        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643981415/Dr_Russell_DSouza_-_Copy_fabqtz.jpg"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643981415/Dr_Russell_DSouza_-_Copy_fabqtz.jpg"
            alt="image1"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">Prof. RUSSELL DSOUZA</p>
          <p className="designation">
            CHAIR<span className="and"> & </span>HEAD OF DEPARTMENT OF EDUCATION
          </p>
        </div>
      </div>

      <div className="images">
        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643981927/Professor_Mary_Mathew_wbgi02.jpg"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643981927/Professor_Mary_Mathew_wbgi02.jpg"
            alt="image1"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">Prof. Mary Mathew</p>
          <p className="designation">CO-CHAIR</p>
        </div>
        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643981961/Prof_Gerhard_Fortwengel_e8nrii.png"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643981961/Prof_Gerhard_Fortwengel_e8nrii.png"
            alt="image1"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">Prof. Gerhard Fortwengel</p>
          <p className="designation">CO-CHAIR</p>
        </div>
        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643981990/Prof_Kristen_Jones-_Bonofigilo_hpveg0.jpg"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643981990/Prof_Kristen_Jones-_Bonofigilo_hpveg0.jpg"
            alt="image1"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">Prof. Kristen Jones Bonofiglio</p>
          <p className="designation">CO-CHAIR</p>
        </div>
        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643982008/Dr_Derek_Dsouza_audgyt.jpg"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643982008/Dr_Derek_Dsouza_audgyt.jpg"
            alt="image1"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">Prof. Derek Dsouza</p>
          <p className="designation">CO-CHAIR</p>
        </div>
        <div className="personCard">
          <ModalImage
            small="https://res.cloudinary.com/unesco-admin/image/upload/v1643982033/Prof_Joseph_Thornton_Uni_of_Florida_USA_o5apkn.png"
            large="https://res.cloudinary.com/unesco-admin/image/upload/v1643982033/Prof_Joseph_Thornton_Uni_of_Florida_USA_o5apkn.png"
            alt="image1"
            className="image"
            hideZoom={true}
            hideDownload={true}
          />
          <p className="name">Prof. Joseph Thornton</p>
          <p className="designation">CO-CHAIR</p>
        </div>
      </div>

      <div className="content">
        <div className="english"></div>
        <p>
          International Chair in Bioethics (Haifa) was established on 24th July
          2001, with the objective of ensuring the global spread of bioethics
          education.
          <br />
          <span
            style={{
              textAlign: "right",
              fontSize: "1.2rem",
              color: "#01471B",
              cursor: "pointer",
            }}
            data-toggle="modal"
            data-target="#aboutUsModalLong"
          >
          </span>
        </p>
      </div>
    </div>
  );
}

export default AboutUS;
